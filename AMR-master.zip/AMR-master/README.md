# AMR
Adaptive Morphological Reconstruction for Seeded Image Segmentation
